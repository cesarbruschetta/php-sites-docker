tinyMCE.addI18n('en.article',{
pagebreak: "Insert / Edit Pagebreak",
readmore: "Insert Read More",
readmore_title: "Read More",
readmore_alert: "There is already a Read More break inserted in this article. Only one such break is permitted. Use a Pagebreak to split the page up further."
});