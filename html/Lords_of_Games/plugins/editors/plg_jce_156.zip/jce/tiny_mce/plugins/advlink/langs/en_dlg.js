tinyMCE.addI18n('en.advlink_dlg',{
title:"Insert/edit link",
is_email:"The URL you entered seems to be an email address, do you want to add the required mailto: prefix?",
is_external:"The URL you entered seems to be an external link, do you want to add the required http:// prefix?",
no_href:"An URL is required. Please select a link or enter an URL"
});