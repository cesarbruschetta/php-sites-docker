// UK lang variables
tinyMCE.addI18n('en.advcode',{
desc : 'Edit Code',
wrap:"Word Wrap",
highlight:"Highlight",
language:"Language",
numbers:"Line Numbers",
autocomplete:"AutoComplete",
'fontsize':"Font Size",
strong: 'Bold',
em: 'Italic',
underline: 'Underline',
removeformat: 'Remove Format',
format: 'Format',
undo: 'Undo',
redo: 'Redo',
delta_width : 0,
delta_height : 0
});
