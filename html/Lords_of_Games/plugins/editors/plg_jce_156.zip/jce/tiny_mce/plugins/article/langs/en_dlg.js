tinyMCE.addI18n('en.pagebreak_dlg',{
desc:"Insert / Edit Pagebreak",
title:"Page Title",
alias:"Table of Contents Alias"
});