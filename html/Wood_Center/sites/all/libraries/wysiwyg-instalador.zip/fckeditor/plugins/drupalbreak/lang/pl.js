FCKLang.DrupalBreakTooltip = 'Wstaw znacznik oznaczający koniec skrótu' ;
FCKLang.DrupalBreakTitle = 'Skrót' ;
