FCKLang.DrupalBreakTooltip = 'Вставить разделитель анонса и основного текста' ;
FCKLang.DrupalBreakTitle = 'Анонс' ;
