FCKLang.DlgBrowse				= 'Browse' ;
FCKLang.DlgLoading				= 'Loading...' ;
FCKLang.DlgLinkToMenu			= 'Link to menu' ;
FCKLang.DlgTitle				= 'Title' ;
FCKLang.DlgChooseCategory		= 'Choose' ;
