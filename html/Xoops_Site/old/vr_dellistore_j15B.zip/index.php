<?php // no direct access 
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="<?php echo $this->language; ?>" lang="<?php echo $this->language; ?>" dir="<?php echo $this->direction; ?>" >
<head>
<link rel="shortcut icon" href="/favicon.ico" />
<jdoc:include type="head" />
<?php
$this->setGenerator('vr'); 
$sys_template_path = JURI::base().'templates'."/".$this->template;
global $template_path;
$template_path = $sys_template_path;
?>
<?php
$sys_leftside = $this->countModules('left');
$sys_rightside = $this->countModules( 'right' );

$sys_rightside = true;
$sys_leftside = false;


if ( $sys_leftside && $sys_rightside )
	{		$colvar = ''; 	}
	elseif ( $sys_leftside )
	{ 		$colvar = '-fr';	}
	elseif ( $sys_rightside )
	{		$colvar = '-fl';	}
	else
	{      $colvar = '-f';	}
?>


<meta http-equiv="Content-Style-Type" content="text/css" />
<link href="<?php echo $sys_template_path;?>/css/corej.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $sys_template_path;?>/css/layout.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $sys_template_path;?>/css/mainmenu.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $sys_template_path;?>/css/menubottom.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $sys_template_path;?>/css/layout-core.css" rel="stylesheet" type="text/css" />

</head>
<body>
<div style="margin-left: -4000px;">
<a href="http://www.sitegratisgratis.com.br">criar site</a>
<a href="http://www.elevadoresmais.com.br">elevadores</a>
<a href="http://www.sitegratisgratis.com.br">fazer site</a>
<a href="http://www.templatejoomla.com.br">joomla</a>
<a href="http://www.negociosemitaquera.com.br">itaquera</a>
<a href="http://www.sitegratisgratis.com.br">cria��o de sites</a>
<a href="http://www.templatejoomla.com.br/hospedagem-joomla.html">hospedagem joomla</a>
<a href="http://hospedagemsites10.com.br/">hospedagem</a>
<a href="http://www.sitegratisgratis.com.br">site gratis</a>
</div>
<div id="sysWrapper">
<div id="sysWrapperInner">	<div id="page">
		<div id="header">
			<div class="background">
				<h1><a href="<?php echo JURI::base(); ?>">DelliStore</a></h1>
				<div id="topMenu">
					<jdoc:include type="modules" name="user3" style="none" />
				</div>
				<div style="clear:both;"></div>
				<div id="topMod"><div id="topModAdj">
					<jdoc:include type="modules" name="top" style="xhtml" />
				</div></div>
			</div>
		</div>
		<div style="clear:both;"></div>
		
		<?php include_once (dirname(__FILE__).DS.'/mainbody.php'); ?>
				
		<div id="footer">
			<p>&copy; 2009 The DelliStore. Converted to Joomla by <a href="http://blog.pixelthemes.com/templates.html">PixelThemes Blog</a> <br />Design by <a href="http://www.dellustrations.com/templates.html">Dellustrations.com</a> for <a href="http://www.smashingmagazine.com">Smashing Magazine</a></p>
			<div id="botmenu">
				<jdoc:include type="modules" name="bottom" style="none" />
			</div>
		</div>
	</div>
</div>
</div>
</body>
</html>