<?php // no direct access 
defined( '_JEXEC' ) or die( 'Restricted access' ); 
?>
<div id="sysPathWay"><jdoc:include type="module" name="breadcrumbs" /></div>
<div style="clear:both;"></div>
<div id="sysContainerWrap">
		<div id="sysContainer<?php echo $colvar; ?>" class="clearfix">
			<!-- content begins here -->
			<div id="sysMainbody<?php echo $colvar; ?>">
			<div id="sysContentWrap">
				<div id="sysContent">
					

					<div id="leftcol">
						<div class="block">
							<div class="block-top"></div>
							<div class="block-content">
								<jdoc:include type="component" />
								<div style="clear:both;"></div>
								<?php if ($this->countModules('banner')) { ?>
								<div id="bannermod">
									<jdoc:include type="modules" name="banner" style="none" />
								</div>
								<?php } ?>
							</div>
							<div class="block-bottom"></div>
						</div>
					</div>

				</div>
			</div>

			<?php if ($sys_rightside) { ?>
			<div id="sysRightCol">
				<div id="sysRightColInner">
					<jdoc:include type="modules" name="right" style="vr" />
				</div>
			</div>
			<?php } ?>

			</div>
			<!-- content ends here -->
		</div>
	</div>
	<div style="clear:both;"></div>