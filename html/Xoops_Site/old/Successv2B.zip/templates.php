<?if( $sg == 'banner' ):?>
<div style="width:137px;text-align:center;margin:0 auto;">
<br />
</div>  
<?else:?>
 	<?php echo $mainframe->getCfg('sitename') ;?>, Designed by <a href="http://www.zuczkowski.pl/" target="_blank">Zuczkowski Media Design Solutions</a> and sponsored by <a href="http://www.affiliate-partner.pl/" target="_blank"> programy partnerskie</a>
 <?endif;?>